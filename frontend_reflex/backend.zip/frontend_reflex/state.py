import reflex as rx
import requests
import os

API_URL = "http://localhost:8000"

class State(rx.State):
    """The app state."""
    
    # Auth State
    token: str = rx.Cookie(name="token")
    user_authenticated: bool = False
    username: str = ""
    
    # Dashboard Data
    total_spend: str = "$0"
    conversions: str = "0"
    cpa: str = "$0.00"
    ctr: str = "0.00%"
    
    def check_auth(self):
        """Check if user is authenticated via token."""
        if self.token:
            self.user_authenticated = True
            self.username = "User" # In real app, fetch from /users/me
            return self.fetch_dashboard_data()
        else:
            self.user_authenticated = False

    def login(self, form_data: dict):
        """Handle login."""
        try:
            # Prepare form data for OAuth2
            data = {
                "username": form_data["username"],
                "password": form_data["password"]
            }
            response = requests.post(f"{API_URL}/token", data=data)
            
            if response.status_code == 200:
                self.token = response.json()["access_token"]
                self.user_authenticated = True
                self.username = form_data["username"]
                return rx.redirect("/")
            else:
                return rx.window_alert("Login failed: Invalid credentials")
        except Exception as e:
            return rx.window_alert(f"Login error: {str(e)}")

    def logout(self):
        """Handle logout."""
        self.token = ""
        self.user_authenticated = False
        return rx.redirect("/")

    def fetch_dashboard_data(self):
        """Fetch dashboard metrics from API."""
        try:
            # Mocking data call since we might not have live data in the API yet
            # In production: response = requests.get(f"{API_URL}/dashboard/metrics", headers={"Authorization": f"Bearer {self.token}"})
            
            # Using mock data for the visual proof
            self.total_spend = "$124,500"
            self.conversions = "3,842"
            self.cpa = "$32.40"
            self.ctr = "2.85%"
        except Exception:
            pass
