import reflex as rx
from .state import State

# --- Components ---

def sidebar_item(text: str, icon: str, url: str) -> rx.Component:
    """A sidebar item."""
    return rx.link(
        rx.hstack(
            rx.icon(icon, size=20, color="rgb(148, 163, 184)"),
            rx.text(text, color="rgb(226, 232, 240)", font_weight="500"),
            spacing="3",
            padding="12px 16px",
            border_radius="12px",
            _hover={"bg": "rgba(59, 130, 246, 0.1)", "color": "white"},
            width="100%",
        ),
        href=url,
        width="100%",
        text_decoration="none",
    )

def sidebar() -> rx.Component:
    """The application sidebar."""
    return rx.box(
        rx.vstack(
            rx.box(
                rx.heading("PCA Agent", size="6", background_image="linear-gradient(to right, #60a5fa, #a78bfa)", background_clip="text", color="transparent"),
                rx.text("Enterprise Analytics", size="1", color="rgb(100, 116, 139)", letter_spacing="1px", font_weight="bold"),
                margin_bottom="2em",
                padding_x="1em"
            ),
            rx.vstack(
                sidebar_item("Overview", "layout-dashboard", "/"),
                sidebar_item("Deep Dive", "bar-chart-2", "/analysis"),
                sidebar_item("AI Assistant", "message-square", "/chat"),
                sidebar_item("Settings", "settings", "/settings"),
                spacing="2",
                width="100%",
            ),
            rx.spacer(),
            rx.button(
                rx.hstack(
                    rx.icon("log-out", size=20),
                    rx.text("Sign Out"),
                    spacing="2",
                ),
                on_click=State.logout,
                variant="ghost",
                color_scheme="red",
                width="100%",
                justify_content="start",
                padding="12px 16px",
            ),
            height="100%",
            padding="2em 1em",
        ),
        width="280px",
        height="100vh",
        position="fixed",
        left="0",
        top="0",
        bg="rgba(15, 23, 42, 0.5)",
        backdrop_filter="blur(20px)",
        border_right="1px solid rgba(148, 163, 184, 0.1)",
        z_index="10",
    )

def metric_card(title: str, value: str, change: str, icon: str, color: str) -> rx.Component:
    """A dashboard metric card."""
    return rx.box(
        rx.vstack(
            rx.hstack(
                rx.icon(icon, color=color, size=24),
                rx.text(title, color="rgb(148, 163, 184)", font_size="0.875rem", font_weight="500"),
                align_items="center",
                spacing="2",
                margin_bottom="1em"
            ),
            rx.hstack(
                rx.heading(value, size="7", color="white"),
                rx.badge(change, color_scheme="green", variant="soft", radius="full"),
                width="100%",
                justify_content="between",
                align_items="end"
            ),
            align_items="start",
            width="100%",
        ),
        padding="1.5em",
        bg="rgba(30, 41, 59, 0.4)",
        border="1px solid rgba(148, 163, 184, 0.2)",
        border_radius="16px",
        width="100%",
        _hover={"border_color": "rgba(59, 130, 246, 0.5)", "transform": "translateY(-2px)", "transition": "all 0.2s"},
    )

def dashboard_content() -> rx.Component:
    """The main dashboard content."""
    return rx.box(
        rx.vstack(
            rx.hstack(
                rx.heading("Dashboard Overview", size="8", color="white"),
                rx.spacer(),
                rx.button("Generate Report", color_scheme="blue", size="3", radius="large"),
                width="100%",
                align_items="center",
                margin_bottom="2em",
            ),
            rx.grid(
                metric_card("Total Spend", State.total_spend, "+12.5%", "dollar-sign", "#60a5fa"),
                metric_card("Conversions", State.conversions, "+8.2%", "users", "#34d399"),
                metric_card("Avg. CPA", State.cpa, "-4.1%", "activity", "#f472b6"),
                metric_card("CTR", State.ctr, "+0.4%", "mouse-pointer", "#fbbf24"),
                columns="4",
                spacing="5",
                width="100%",
                margin_bottom="2em",
            ),
            rx.grid(
                rx.box(
                    rx.heading("Performance Trend", size="4", color="white", margin_bottom="1em"),
                    rx.center(rx.text("Chart Placeholder", color="gray"), height="300px", border="2px dashed rgba(148, 163, 184, 0.1)", border_radius="12px"),
                    bg="rgba(30, 41, 59, 0.4)",
                    padding="1.5em",
                    border_radius="16px",
                    border="1px solid rgba(148, 163, 184, 0.1)",
                ),
                rx.box(
                    rx.heading("Device Breakdown", size="4", color="white", margin_bottom="1em"),
                     rx.center(rx.text("Chart Placeholder", color="gray"), height="300px", border="2px dashed rgba(148, 163, 184, 0.1)", border_radius="12px"),
                    bg="rgba(30, 41, 59, 0.4)",
                    padding="1.5em",
                    border_radius="16px",
                    border="1px solid rgba(148, 163, 184, 0.1)",
                ),
                columns="3",
                spacing="5",
                width="100%",
            ),
            width="100%",
            max_width="1280px",
            padding_x="2em",
            padding_y="2em",
        ),
        margin_left="280px",
        min_height="100vh",
        bg="linear-gradient(135deg, #0f172a 0%, #1e293b 100%)",
    )

def login_page() -> rx.Component:
    """The login page."""
    return rx.center(
        rx.vstack(
            rx.heading("Welcome Back", size="8", color="white", margin_bottom="0.5em"),
            rx.text("Sign in to your account", color="rgb(148, 163, 184)", margin_bottom="2em"),
            rx.form(
                rx.vstack(
                    rx.input(placeholder="Username", id="username", width="100%"),
                    rx.input(placeholder="Password", type="password", id="password", width="100%"),
                    rx.button("Sign In", type="submit", width="100%", size="3"),
                    spacing="4",
                    width="100%",
                ),
                on_submit=State.login,
                width="300px",
            ),
            bg="rgba(30, 41, 59, 0.5)",
            padding="3em",
            border_radius="24px",
            border="1px solid rgba(148, 163, 184, 0.2)",
            backdrop_filter="blur(20px)",
        ),
        height="100vh",
        bg="linear-gradient(135deg, #0f172a 0%, #020617 100%)",
    )

# --- Pages ---

def index() -> rx.Component:
    return rx.cond(
        State.user_authenticated,
        rx.box(sidebar(), dashboard_content()),
        login_page(),
    )

app = rx.App(
    theme=rx.theme(
        appearance="dark",
        has_background=True,
        radius="large",
        accent_color="blue",
    ),
    stylesheets=[
        "https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap",
    ],
    style={
        "font_family": "Inter, sans-serif",
    }
)

app.add_page(index, on_load=State.check_auth)
